package com.mongo.crud.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mongo.crud.pojo.Tutorial;
import com.mongo.crud.repository.TutorialRepository;

@Service
public class TutorialService {
	
	@Autowired
	TutorialRepository tutorialRepository;
	
	//create
	public Tutorial createTutorial( Tutorial tutorial) {
			return tutorialRepository.save(tutorial);
	}
	
	//Read All
	public List<Tutorial>   getAllTutorials(){
		return tutorialRepository.findAll();
	}
	
	public Optional<Tutorial> getTutorialById(String id){
		return tutorialRepository.findById(id);
	}
	
	//Delete
	public void removeTutorial(String id) {
			tutorialRepository.deleteById(id);
	}
	
	public void removeAllTutorial() {
		tutorialRepository.deleteAll();
	}
	
	public void removeTutorial(Tutorial tutorial) {
		tutorialRepository.delete(tutorial);
	}
	
	public Tutorial updateTutorial(String id , Tutorial tutorial) {
		Optional<Tutorial> tut = tutorialRepository.findById(id);
		if (tut.isPresent()) {
			Tutorial outTut=tut.get();
			outTut.setDescription(tutorial.getDescription());
			outTut.setPublished(tutorial.isPublished());
			outTut.setTitle(tutorial.getTitle());
			
			return tutorialRepository.save(outTut);
			 
		}
				return null; 	
	}
	
	
	
}
