package com.mongo.crud.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mongo.crud.pojo.Tutorial;
import com.mongo.crud.service.TutorialService;

@RequestMapping("/tutorial")
@RestController
public class TutorialController {
	@Autowired	
	private TutorialService tutorialService;  
	
	@GetMapping("/{id}")
	public ResponseEntity<Optional<Tutorial>> getTutorialById(@PathVariable("id") String id ){
			
			Optional<Tutorial> tutorial = tutorialService.getTutorialById(id);
			return new ResponseEntity<>(tutorial,HttpStatus.OK);
		
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<Tutorial>> getAllTutorials(){
			return new ResponseEntity<>(tutorialService.getAllTutorials(),HttpStatus.OK);
	}
	
	@PostMapping("/add")
	public ResponseEntity<Tutorial> createTutorial(@RequestBody Tutorial tutorial){
		
		return new ResponseEntity<>(tutorialService.createTutorial(tutorial),HttpStatus.CREATED);
	}
	
	@PutMapping("/modify/{id}")
	public ResponseEntity<Tutorial> updateTutorial(@PathVariable("id") String id , @RequestBody Tutorial tutorial){
		
		return new ResponseEntity<>(tutorialService.updateTutorial(id,tutorial),HttpStatus.OK);
	}
	
	@DeleteMapping("/remove/{id}")
	public ResponseEntity<HttpStatus> deleteTutorial(@PathVariable("id") String id ){
			
				tutorialService.removeTutorial(id);
			
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
	}
	
	
	
	
	
	
	
	
}
