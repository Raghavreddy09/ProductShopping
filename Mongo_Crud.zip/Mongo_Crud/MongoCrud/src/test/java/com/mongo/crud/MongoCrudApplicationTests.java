package com.mongo.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
