package com.productshopping.productcatalogservice.entity;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;



@Document(collection = "products")
public class Product {
		
		@Id
		private BigInteger productId;
	    private String productName;
	    private BigDecimal price;
	    private String description;
	    private String category;
	    private int quantity;
		public BigInteger getProductId() {
			return productId;
		}
		public void setProductId(BigInteger productId) {
			this.productId = productId;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public BigDecimal getPrice() {
			return price;
		}
		public void setPrice(BigDecimal price) {
			this.price = price;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public Product(BigInteger productId, String productName, BigDecimal price, String description, String category,
				int quantity) {
			super();
			this.productId = productId;
			this.productName = productName;
			this.price = price;
			this.description = description;
			this.category = category;
			this.quantity = quantity;
		}
		public Product() {
			super();
		}

}
