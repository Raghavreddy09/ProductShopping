package com.productshopping.userservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductShoppingUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
