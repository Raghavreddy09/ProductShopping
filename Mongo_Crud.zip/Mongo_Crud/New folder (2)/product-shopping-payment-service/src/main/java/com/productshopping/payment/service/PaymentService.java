package com.productshopping.payment.service;

import java.math.BigDecimal;


public interface PaymentService {
		
	public String doPayment(int userId, BigDecimal amount);
}
