package com.productshopping.payment.service;

import java.math.BigDecimal;
import java.util.Random;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.productshopping.payment.entity.Payment;
import com.productshopping.payment.repository.PaymentRepository;
import com.productshopping.payment.utility.RandomString;

@Service
public class PaymentServiceImpl implements PaymentService {
	
	@Autowired
	private PaymentRepository paymentRepository;
	
	

	public String doPayment(int userId, BigDecimal amount) {
		Payment payment = new Payment();
			payment.setUserId(userId);
		if (amount!=null) {
			payment.setAmount(amount);
			payment.setPaymentStatus("PAID");
		}
		else
			payment.setPaymentStatus("PENDING");
		payment.setTransctionId(RandomStringUtils.randomAlphabetic(10));
		Payment outpay = paymentRepository.save(payment);
		return outpay.getPaymentStatus();
	}



		
	
}
