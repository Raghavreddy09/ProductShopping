package com.productshopping.orderservice.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.productshopping.orderservice.entity.Cart;

public interface CartRepository extends MongoRepository<Cart, Integer> {

	@Query("{ 'cartId': ?0}")
	public List<Cart> getProductsFromCart(int cartId);
}
