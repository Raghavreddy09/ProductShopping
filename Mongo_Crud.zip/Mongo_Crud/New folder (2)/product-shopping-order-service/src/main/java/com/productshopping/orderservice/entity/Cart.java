package com.productshopping.orderservice.entity;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Cart {
	
	@Id
	private int cartId;
	private BigInteger productId;
	private int quantity;
	private User user;
	private BigDecimal subTotal;
	
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public BigInteger getProductId() {
		return productId;
	}
	public void setProductId(BigInteger productId) {
		this.productId = productId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	public BigDecimal getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(BigDecimal subTotal) {
		this.subTotal = subTotal;
	}
	
	public Cart(int cartId, BigInteger productId, int quantity, User user, BigDecimal subTotal) {
		super();
		this.cartId = cartId;
		this.productId = productId;
		this.quantity = quantity;
		this.user = user;
		this.subTotal = subTotal;
	}
	public Cart() {
		super();
	}
	
	
	
}
