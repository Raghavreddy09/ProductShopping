package com.productshopping.orderservice.utilities;

import java.math.BigDecimal;

import com.productshopping.orderservice.entity.Product;

public class CartUtilities {
	
	public static BigDecimal getSubTotalForProduct(Product product,int quantity) {
		return (product.getPrice()).multiply(BigDecimal.valueOf(quantity));
	}
}
