package com.productshopping.orderservice.controller;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.productshopping.orderservice.entity.Product;
import com.productshopping.orderservice.feignclient.ProductClient;
import com.productshopping.orderservice.service.CartServiceImpl;

@RestController
@RequestMapping("/cart")
public class CartController {
	
	 

	@Autowired
	private ProductClient productClient;
	
	@Autowired
	private CartServiceImpl cartService;
	
	@GetMapping("/allproducts")
	public ResponseEntity<List<Product>> getAllProductsToPurchase(){
		List <Product> products = productClient.getAllProducts();
		return new ResponseEntity<>(products,HttpStatus.OK);
		
	}
	
	@PostMapping(value="/add",params= {"userId","productId","quantity"})
	public ResponseEntity<Product> addProductToCart(@RequestParam("userId") int userId,
			@RequestParam("productId") BigInteger productId,
			@RequestParam("quantity") int quantity){
		
		Product product = productClient.getOneProductById(productId);
				
		if (product!=null) {
			cartService.addProductToCart(userId, productId, quantity);
			return new ResponseEntity<>(product,HttpStatus.OK);
			
		}			
		else
			return new ResponseEntity<>(product,HttpStatus.NOT_FOUND);
			
	}
	
}
