package com.productshopping.orderservice.feignclient;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.productshopping.orderservice.entity.Product;

@FeignClient(name = "product-catalog-service")
public interface ProductClient {
	
	@GetMapping(value = "/product/all")
	public List<Product> getAllProducts();
	
	@GetMapping(value = "/product/{id}")
	public Product getOneProductById(@PathVariable("id") BigInteger productId);
	
}
