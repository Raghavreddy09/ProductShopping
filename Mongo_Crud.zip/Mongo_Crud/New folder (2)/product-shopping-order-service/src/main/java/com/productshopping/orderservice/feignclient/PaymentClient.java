package com.productshopping.orderservice.feignclient;

import java.math.BigDecimal;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@FeignClient(name = "payment-service")
public interface PaymentClient {
   @PostMapping(value = "/payment/cash",params = {"userId","amount"})
   public String doPayment(@RequestParam ("userId") int userId,
            @RequestParam("amount") BigDecimal amount);
	
}
