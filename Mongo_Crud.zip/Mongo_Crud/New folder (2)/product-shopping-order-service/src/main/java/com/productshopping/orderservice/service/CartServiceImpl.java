package com.productshopping.orderservice.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.productshopping.orderservice.entity.Cart;
import com.productshopping.orderservice.entity.Product;
import com.productshopping.orderservice.entity.User;
import com.productshopping.orderservice.feignclient.ProductClient;
import com.productshopping.orderservice.feignclient.UserClient;
import com.productshopping.orderservice.repository.CartRepository;
import com.productshopping.orderservice.utilities.CartUtilities;


@Service
public class CartServiceImpl implements CartService {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	CartRepository cartRepository;
	@Autowired
	UserClient userClient;
	@Autowired
	ProductClient productClient;

	@Override
	public Cart addProductToCart(int userId, BigInteger productId, int quantity) {
		Cart cart = new Cart();
		logger.info("calling userservice from cartservice...");
		User user = userClient.getUserById(userId);
		logger.info("calling productcatalog from cartservice...");
		Product product = productClient.getOneProductById(productId);
		product.setTotal(CartUtilities.getSubTotalForProduct(product, quantity));
		if (user!=null) {
			cart.setUser(user);
		cart.setCartId(userId);
		cart.setProductId(productId);
		cart.setQuantity(quantity);
		return cartRepository.save(cart);
		}
		else 
		{
			System.err.println("User DoesNot Exist");
			return null;
		}
	}
	public List<Product> getProductsFromCart(int cartId) {
		List<Cart> cartList = new ArrayList<>();
		List<Product> products = new ArrayList<>();
		cartList.addAll((ArrayList<Cart>)cartRepository.getProductsFromCart((cartId)));
		for(Cart eachItem : cartList ) {
			Product product = productClient.getOneProductById(eachItem.getProductId()); 
			products.add(product);
		}
		return products;	
	}
	
	/*
	@Override
	public Map<Product,Integer> getAllProductsFromCart(Iterable<Integer> cartId) {
		List<Cart> cartList = new ArrayList<>();
		Map<Product,Integer> products = new HashMap<>();
		cartList.addAll((ArrayList<Cart>) cartRepository.findAllById(cartId));
		for(Cart eachItem : cartList ) {
			BigInteger productId = eachItem.getProductId();
			int quantity = eachItem.getQuantity();
			Product product = productClient.getOneProductById(productId); 
			if (products.containsKey(product)) 				
				products.put(product,products.get(product)+quantity);
			else
				products.put(product, quantity);
			
		}
		return products;	
	}
	*/
	
	
}
