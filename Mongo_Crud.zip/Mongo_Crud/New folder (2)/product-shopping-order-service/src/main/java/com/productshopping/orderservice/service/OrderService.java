package com.productshopping.orderservice.service;

import com.productshopping.orderservice.entity.Order;

public interface OrderService {
		
	public Order saveOrder(int id);
}
