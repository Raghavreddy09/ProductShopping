package com.productshopping.orderservice.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.productshopping.orderservice.entity.User;

@FeignClient(name = "user-service")
public interface UserClient {
	@GetMapping(value = "/user/{id}")
    public User getUserById(@PathVariable("id") int id);
	
}
