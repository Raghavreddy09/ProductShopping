package com.productshopping.orderservice.service;

import java.math.BigInteger;
import java.util.Map;

import org.springframework.data.mongodb.repository.Query;

import com.productshopping.orderservice.entity.Cart;
import com.productshopping.orderservice.entity.Product;

public interface CartService {
		public Cart addProductToCart(int cartId,BigInteger productId,int quantity);
//		public Map<Product, Integer> getAllProductsFromCart(Iterable<Integer> cartId);
		
		
}
