package com.productshopping.orderservice.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.productshopping.orderservice.entity.Order;
import com.productshopping.orderservice.entity.Product;
import com.productshopping.orderservice.entity.User;
import com.productshopping.orderservice.feignclient.PaymentClient;
import com.productshopping.orderservice.feignclient.ProductClient;
import com.productshopping.orderservice.feignclient.UserClient;
import com.productshopping.orderservice.repository.OrderRepository;
import com.productshopping.orderservice.utilities.OrderUtilities;

import feign.FeignException;


@Service
public class OrderServiceImpl implements OrderService {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private CartServiceImpl cartService;
			
	@Autowired
	private UserClient userClient;
	
	@Autowired
	private PaymentClient paymentClient;
	
	@Override
	public Order saveOrder(int userId) {
		
		User user = null;
		String paymentStatus = "";
		try {
			logger.info("calling user-service from the order-service...");
			user = userClient.getUserById(userId);
		} catch (FeignException feignException) {
				
			logger.error(feignException.getLocalizedMessage());
		}
		Order order = new Order();
		order.setUser(user);
		List<Product> products =cartService.getProductsFromCart(userId);
		order.setProducts(products);
		BigDecimal orderedTotal = OrderUtilities.countTotalPrice(order.getProducts());
		order.setTotal(orderedTotal);
		
		logger.info("calling paymen-service from the order-service...");
		try {
			paymentStatus =paymentClient.doPayment(userId, orderedTotal);
			order.setStatus(paymentStatus);
		} catch (FeignException feignException) {
			logger.error(feignException.getLocalizedMessage());
		}
		return orderRepository.save(order);
	}

}
