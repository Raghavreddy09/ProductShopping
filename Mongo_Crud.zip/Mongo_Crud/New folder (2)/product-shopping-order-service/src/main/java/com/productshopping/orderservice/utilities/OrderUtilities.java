package com.productshopping.orderservice.utilities;

import java.math.BigDecimal;
import java.util.List;
import com.productshopping.orderservice.entity.Product;

public class OrderUtilities {
	
	 public static BigDecimal countTotalPrice(List<Product> product){
	        BigDecimal total = BigDecimal.ZERO;
	        if (!product.isEmpty()) {
	        for(int i = 0; i < product.size(); i++){
	            total = total.add(product.get(i).getTotal());
	        }
	        return total;
	        }
	        return total;
	    }
	

}
