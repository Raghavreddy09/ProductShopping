package com.productshopping.orderservice.entity;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;



@Document(collection = "orders")

public class Order {

	
	@Id
	private String orderId;
    private String status;
    private BigDecimal total;
    private List<Product> products;
    private User user;
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public BigDecimal getTotal() {
		return total;
	}
	public void setTotal(BigDecimal total) {
		this.total = total;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Order(String orderId, String status, BigDecimal total, List<Product> products, User user) {
		super();
		this.orderId = orderId;
		this.status = status;
		this.total = total;
		this.products = products;
		this.user = user;
	}
	public Order() {
		super();
	}
    
    
    
    
    
}
