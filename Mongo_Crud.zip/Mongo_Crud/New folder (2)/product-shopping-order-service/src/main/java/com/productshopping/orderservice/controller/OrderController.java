package com.productshopping.orderservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.productshopping.orderservice.entity.Order;
import com.productshopping.orderservice.service.OrderServiceImpl;

@RestController
@RequestMapping("/order")
public class OrderController {

	@Autowired
	private OrderServiceImpl orderServiceImpl;
	
	Logger logger = LoggerFactory.getLogger(this.getClass()); 
	
	@PostMapping(value ="/placeOrder" ,params= {"userId"} )
	public ResponseEntity<Order> saveOrder(@RequestParam ("userId") int userId) {
		logger.info("calling orderservice Impl... ");
		Order order = orderServiceImpl.saveOrder(userId);
		return new ResponseEntity<>(order, HttpStatus.OK); 
	}
	

}
